document.addEventListener("DOMContentLoaded", function () {
  // Reading progress bar
  var bar = document.getElementById("progress");
  window.addEventListener("scroll", function () {
    var h = document.documentElement;
    var max = h.scrollHeight - h.clientHeight;
    bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + "%";
  });

  // Syntax highlighting and copy buttons for code blocks
  document.querySelectorAll(".content pre").forEach(function (pre) {
    var code = pre.querySelector("code");
    if (window.hljs && code) hljs.highlightElement(code);
    var btn = document.createElement("button");
    btn.className = "copy-btn";
    btn.type = "button";
    btn.textContent = "Copy";
    btn.onclick = function () {
      navigator.clipboard.writeText(code ? code.innerText : pre.innerText).then(function () {
        btn.textContent = "Copied!";
        setTimeout(function () { btn.textContent = "Copy"; }, 1500);
      });
    };
    pre.appendChild(btn);
  });

  // Save / unsave article without reloading
  var form = document.getElementById("bookmark-form");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      fetch(form.action, {
        method: "POST",
        body: new FormData(form),
        headers: { "X-Requested-With": "XMLHttpRequest" },
      }).then(function (r) { return r.json(); }).then(function (d) {
        var b = document.getElementById("bookmark-btn");
        b.className = "btn btn-sm " + (d.saved ? "btn-warning" : "btn-outline-warning");
        b.textContent = d.saved ? "🔖 Saved" : "🔖 Save";
      }).catch(function () { form.submit(); });
    });
  }
});
