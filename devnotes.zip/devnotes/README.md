# DevNotes – Django Blog / Content Website (articles and tutorials)

```
python -m venv venv
venv\Scripts\activate          # Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python manage.py makemigrations content
python manage.py migrate
python manage.py seed          # demo content (staff login: demo_author / demo12345)
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/  Write content at /admin/ (Articles, Series, Tags). Body is written in Markdown.

Features: Markdown articles with auto table of contents, code highlighting and copy button,
tutorial series with lessons and previous/next navigation, tags, search, filters, pagination,
reading progress bar, bookmarks, newsletter subscription, RSS feed (/feed/), signup/login.
