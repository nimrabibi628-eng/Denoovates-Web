from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils.text import slugify


def unique_slug(model, text, pk=None):
    base = slugify(text) or "item"
    slug, n = base, 2
    while model.objects.filter(slug=slug).exclude(pk=pk).exists():
        slug = f"{base}-{n}"
        n += 1
    return slug


class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(unique=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Series(models.Model):
    LEVELS = [("beginner", "Beginner"), ("intermediate", "Intermediate"), ("advanced", "Advanced")]
    title = models.CharField(max_length=150)
    slug = models.SlugField(unique=True, blank=True)
    description = models.TextField(blank=True)
    level = models.CharField(max_length=15, choices=LEVELS, default="beginner")
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "series"
        ordering = ["title"]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = unique_slug(Series, self.title, self.pk)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("series_detail", args=[self.slug])


class Article(models.Model):
    KINDS = [("article", "Article"), ("tutorial", "Tutorial")]
    STATUS = [("draft", "Draft"), ("published", "Published")]

    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="articles")
    kind = models.CharField(max_length=10, choices=KINDS, default="article")
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    summary = models.CharField(max_length=250)
    body = models.TextField(help_text="Write in Markdown. Use ## for headings and ``` for code blocks.")
    cover = models.ImageField(upload_to="covers/", blank=True)
    tags = models.ManyToManyField(Tag, blank=True, related_name="articles")
    series = models.ForeignKey(Series, on_delete=models.SET_NULL, null=True, blank=True, related_name="articles")
    order = models.PositiveIntegerField(default=0, help_text="Lesson number inside a series")
    featured = models.BooleanField(default=False)
    status = models.CharField(max_length=10, choices=STATUS, default="published")
    views = models.PositiveIntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created"]

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = unique_slug(Article, self.title, self.pk)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("article_detail", args=[self.slug])

    @property
    def read_time(self):
        return max(1, len(self.body.split()) // 200)


class Bookmark(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="bookmarks")
    article = models.ForeignKey(Article, on_delete=models.CASCADE, related_name="bookmarks")
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "article")
        ordering = ["-created"]


class Subscriber(models.Model):
    email = models.EmailField(unique=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email
