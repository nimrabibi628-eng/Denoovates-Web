import markdown


def render_markdown(text):
    """Convert Markdown to HTML and return (html, table_of_contents_html)."""
    md = markdown.Markdown(
        extensions=["fenced_code", "tables", "toc", "sane_lists"],
        extension_configs={"toc": {"toc_depth": "2-3"}},
    )
    html = md.convert(text)
    toc = md.toc if "<li>" in md.toc else ""
    return html, toc
