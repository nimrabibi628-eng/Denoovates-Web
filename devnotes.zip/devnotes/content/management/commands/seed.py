from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.utils.text import slugify

from content.models import Article, Series, Tag

LESSONS = [
    ("Installing Django", "Set up Python, a virtual environment and Django.",
     "## What you need\n\nYou need **Python 3.10+** and `pip`.\n\n## Create a virtual environment\n\n```bash\npython -m venv venv\nvenv\\Scripts\\activate\npip install django\n```\n\n## Check the install\n\n```bash\npython -m django --version\n```\n\nIf you see a version number, you are ready for the next lesson."),
    ("Your first Django project", "Create a project and run the development server.",
     "## Start a project\n\n```bash\ndjango-admin startproject mysite\ncd mysite\npython manage.py runserver\n```\n\n## What was created?\n\n| File | Purpose |\n|------|---------|\n| manage.py | Command line helper |\n| settings.py | Project settings |\n| urls.py | URL routes |\n\nOpen `http://127.0.0.1:8000/` to see the welcome page."),
    ("Models and the admin", "Store data with models and manage it in the admin panel.",
     "## Write a model\n\n```python\nfrom django.db import models\n\nclass Note(models.Model):\n    title = models.CharField(max_length=100)\n    text = models.TextField()\n```\n\n## Migrate\n\n```bash\npython manage.py makemigrations\npython manage.py migrate\n```\n\n## Register in admin\n\nAdd `admin.site.register(Note)` and visit `/admin/`."),
]

ARTICLES = [
    ("Why every student needs a portfolio", "A portfolio shows your work better than any CV.", True,
     "## Show, don't tell\n\nA CV lists skills. A portfolio **proves** them.\n\n## What to include\n\n- Three to five of your best projects\n- Links to live demos and GitHub\n- A short, honest *About me*\n\n## Keep it simple\n\nA fast, clean site beats a complicated one."),
    ("Five habits of good developers", "Small habits that make a big difference over time.", False,
     "## 1. Read error messages\n\nThe answer is usually in the message.\n\n## 2. Commit often\n\nSmall commits are easy to understand and undo.\n\n## 3. Write things down\n\nNotes save hours later.\n\n## 4. Ask good questions\n\nShare what you tried and what you expected.\n\n## 5. Take breaks\n\nFresh eyes find bugs faster."),
]


class Command(BaseCommand):
    help = "Create demo author, tags, a tutorial series and articles"

    def handle(self, *args, **options):
        User = get_user_model()
        author, created = User.objects.get_or_create(username="demo_author", defaults={"is_staff": True})
        if created:
            author.set_password("demo12345")
            author.save()

        tags = {n: Tag.objects.get_or_create(name=n, defaults={"slug": slugify(n)})[0]
                for n in ["Django", "Python", "Career", "Productivity"]}
        series, _ = Series.objects.get_or_create(
            title="Django for Beginners",
            defaults={"description": "A step by step introduction to building websites with Django.", "level": "beginner"})

        added = 0
        for i, (title, summary, body) in enumerate(LESSONS, start=1):
            a, new = Article.objects.get_or_create(slug=slugify(title), defaults={
                "author": author, "kind": "tutorial", "title": title, "summary": summary,
                "body": body, "series": series, "order": i})
            if new:
                a.tags.set([tags["Django"], tags["Python"]])
                added += 1
        for title, summary, featured, body in ARTICLES:
            a, new = Article.objects.get_or_create(slug=slugify(title), defaults={
                "author": author, "kind": "article", "title": title, "summary": summary,
                "body": body, "featured": featured})
            if new:
                a.tags.set([tags["Career"], tags["Productivity"]])
                added += 1
        self.stdout.write(self.style.SUCCESS(f"Added {added} items. Staff login: demo_author / demo12345"))
