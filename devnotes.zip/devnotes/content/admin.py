from django.contrib import admin

from .models import Article, Bookmark, Series, Subscriber, Tag


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Series)
class SeriesAdmin(admin.ModelAdmin):
    list_display = ("title", "level", "created")


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ("title", "kind", "series", "order", "featured", "status", "views", "created")
    list_filter = ("kind", "status", "featured", "series", "tags")
    list_editable = ("status", "featured")
    search_fields = ("title", "body")
    filter_horizontal = ("tags",)


admin.site.register(Subscriber)
admin.site.register(Bookmark)
