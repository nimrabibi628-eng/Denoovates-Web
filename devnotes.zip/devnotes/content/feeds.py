from django.contrib.syndication.views import Feed

from .models import Article


class LatestFeed(Feed):
    title = "DevNotes – latest articles and tutorials"
    link = "/"
    description = "New articles and tutorials from DevNotes."

    def items(self):
        return Article.objects.filter(status="published")[:20]

    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return item.summary
