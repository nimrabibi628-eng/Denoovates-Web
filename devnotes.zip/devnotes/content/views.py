from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Count, F, Q
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from .forms import SignupForm, SubscribeForm
from .markdown_utils import render_markdown
from .models import Article, Bookmark, Series, Subscriber, Tag


def published():
    return Article.objects.filter(status="published").select_related("series").prefetch_related("tags")


def home(request):
    featured = published().filter(featured=True)[:3] or published()[:3]
    latest = published()[:6]
    series = Series.objects.annotate(n=Count("articles", filter=Q(articles__status="published"))).filter(n__gt=0)[:3]
    tags = Tag.objects.annotate(n=Count("articles", filter=Q(articles__status="published"))).filter(n__gt=0)
    return render(request, "content/home.html", {"featured": featured, "latest": latest, "series_list": series, "tags": tags})


def article_list(request):
    items = published()
    q = request.GET.get("q", "").strip()
    kind = request.GET.get("kind", "")
    tag = request.GET.get("tag", "")
    if q:
        items = items.filter(Q(title__icontains=q) | Q(summary__icontains=q) | Q(body__icontains=q))
    if kind in ("article", "tutorial"):
        items = items.filter(kind=kind)
    if tag:
        items = items.filter(tags__slug=tag)
    page = Paginator(items.distinct(), 9).get_page(request.GET.get("page"))
    params = request.GET.copy()
    params.pop("page", None)
    tags = Tag.objects.annotate(n=Count("articles", filter=Q(articles__status="published"))).filter(n__gt=0)
    return render(request, "content/article_list.html", {
        "page": page, "q": q, "kind": kind, "active_tag": tag, "tags": tags, "querystring": params.urlencode(),
    })


def article_detail(request, slug):
    article = get_object_or_404(Article.objects.select_related("series", "author").prefetch_related("tags"), slug=slug)
    if article.status != "published" and not request.user.is_staff:
        raise Http404
    if article.status == "published":
        Article.objects.filter(pk=article.pk).update(views=F("views") + 1)
        article.refresh_from_db(fields=["views"])

    html, toc = render_markdown(article.body)

    lessons, prev_lesson, next_lesson = [], None, None
    if article.series:
        lessons = list(article.series.articles.filter(status="published").order_by("order", "created"))
        ids = [a.pk for a in lessons]
        if article.pk in ids:
            i = ids.index(article.pk)
            prev_lesson = lessons[i - 1] if i > 0 else None
            next_lesson = lessons[i + 1] if i < len(lessons) - 1 else None

    related = published().filter(tags__in=article.tags.all()).exclude(pk=article.pk).distinct()[:3]
    bookmarked = request.user.is_authenticated and Bookmark.objects.filter(user=request.user, article=article).exists()
    return render(request, "content/article_detail.html", {
        "article": article, "html": html, "toc": toc, "lessons": lessons,
        "prev_lesson": prev_lesson, "next_lesson": next_lesson,
        "related": related, "bookmarked": bookmarked,
    })


def series_list(request):
    series = Series.objects.annotate(n=Count("articles", filter=Q(articles__status="published"))).filter(n__gt=0)
    return render(request, "content/series_list.html", {"series_list": series})


def series_detail(request, slug):
    series = get_object_or_404(Series, slug=slug)
    lessons = series.articles.filter(status="published").order_by("order", "created")
    return render(request, "content/series_detail.html", {"series": series, "lessons": lessons})


@login_required
@require_POST
def bookmark_toggle(request, slug):
    article = get_object_or_404(Article, slug=slug, status="published")
    obj, created = Bookmark.objects.get_or_create(user=request.user, article=article)
    if not created:
        obj.delete()
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return JsonResponse({"saved": created})
    return redirect(article)


@login_required
def bookmarks(request):
    items = Bookmark.objects.filter(user=request.user, article__status="published").select_related("article")
    return render(request, "content/bookmarks.html", {"items": items})


@require_POST
def subscribe(request):
    form = SubscribeForm(request.POST)
    if form.is_valid():
        _, created = Subscriber.objects.get_or_create(email=form.cleaned_data["email"].lower())
        messages.success(request, "Thanks for subscribing!" if created else "You are already subscribed.")
    else:
        messages.error(request, "Please enter a valid email address.")
    nxt = request.POST.get("next", "")
    if not url_has_allowed_host_and_scheme(nxt, allowed_hosts={request.get_host()}):
        nxt = "/"
    return redirect(nxt)


def signup(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = SignupForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.save())
        messages.success(request, "Welcome! Your account has been created.")
        return redirect("home")
    return render(request, "registration/signup.html", {"form": form})
