from django.contrib.auth import views as auth_views
from django.urls import path

from . import views
from .feeds import LatestFeed
from .forms import LoginForm

urlpatterns = [
    path("", views.home, name="home"),
    path("articles/", views.article_list, name="article_list"),
    path("articles/<slug:slug>/", views.article_detail, name="article_detail"),
    path("articles/<slug:slug>/bookmark/", views.bookmark_toggle, name="bookmark_toggle"),
    path("series/", views.series_list, name="series_list"),
    path("series/<slug:slug>/", views.series_detail, name="series_detail"),
    path("bookmarks/", views.bookmarks, name="bookmarks"),
    path("subscribe/", views.subscribe, name="subscribe"),
    path("feed/", LatestFeed(), name="feed"),
    path("accounts/signup/", views.signup, name="signup"),
    path("accounts/login/", auth_views.LoginView.as_view(authentication_form=LoginForm), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
]
